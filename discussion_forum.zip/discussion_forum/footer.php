<hr>

<footer>
  <div class="container">
    <div class="row">
      <div class="col-sm-6">
	 
        
      </div>
      <div class="col-sm-6">
          <p class="pull-right">Developed by Group 14</p>      
      </div>
    </div>
  </div>
</footer>
        
        <script type='text/javascript' src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>


        <script type='text/javascript' src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>




        
       
        
        <script type='text/javascript'>
        
        $(document).ready(function() {
        
      
        });
        
        </script>