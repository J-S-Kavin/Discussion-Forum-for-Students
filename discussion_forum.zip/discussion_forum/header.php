<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
        <title>Student Discussion Forum</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-glyphicons.css" type="text/css" rel="stylesheet">
		<link href="css/font-awesome.css" type="text/css" rel="stylesheet">
		<link href="css/my_style.css" type="text/css" rel="stylesheet">
	</head>
	<?php include('dbcon.php'); ?>